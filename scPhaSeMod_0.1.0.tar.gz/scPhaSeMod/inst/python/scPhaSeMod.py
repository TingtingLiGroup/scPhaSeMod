import pandas as pd
import os
import gseapy
import networkx as nx
from collections import defaultdict
from tqdm import tqdm

# Load data
def load_data(uni_gene_path, human_ppi_f_path):
    uni_gene = pd.read_csv(uni_gene_path) 
    human_ppi_f = pd.read_csv(human_ppi_f_path, index_col=0)
    gene_uni_dict = {uni_gene.iloc[i, 5]: uni_gene.iloc[i, 1] for i in range(len(uni_gene))}
    
    return uni_gene, human_ppi_f, gene_uni_dict

# Load gene orders
def load_gene_orders(path, gene_uni_dict):
    files = [file for file in os.listdir(path) if file.endswith('_GeneOrder_origin.csv')]
    celltp_clu_uni, celltp_clu_gene = {}, {}

    for file in files:
        celltype = file.split('_GeneOrder')[0]
        file_clu = pd.read_csv(os.path.join(path, file))
        file_clu = file_clu[file_clu['pearson'] > 0.8]
        
        clu_gene, clu_uni = defaultdict(list), defaultdict(list)
        for i in range(len(file_clu)):
            if file_clu.iloc[i, 2] in gene_uni_dict:
                clu_uni['cluster' + str(file_clu.iloc[i, 3])].append(gene_uni_dict[file_clu.iloc[i, 2]])
                clu_gene['cluster' + str(file_clu.iloc[i, 3])].append(file_clu.iloc[i, 2])
        
        celltp_clu_uni[celltype] = clu_uni
        celltp_clu_gene[celltype] = clu_gene
    
    return celltp_clu_uni, celltp_clu_gene

# Perform GSEA analysis
def run_gsea_analysis(celltp_clu_gene, gene_uni_dict, uni_gene, gmt_path):
    data_df = uni_gene[['Gene', 'saps']]
    pre_df = pd.DataFrame(columns=['Name', 'Term', 'ES', 'NES', 'NOM p-val', 'FDR q-val', 'FWER p-val', 'Tag %', 'Gene %', 'Lead_genes'])

    for celltype in tqdm(celltp_clu_gene):
        genesets = celltp_clu_gene[celltype]
        pre_res = gseapy.prerank(rnk=data_df, gene_sets=genesets, processes=4, outdir=f'scPhaSeMod/{celltype}/prerank_report_kegg', format='png', seed=6)
        pre_res.res2d['cell type'] = celltype
        pre_df = pd.concat([pre_df, pre_res.res2d], ignore_index=True)

    return pre_df

# Filter significant results and save
def filter_and_save_results(pre_df, celltp_clu_gene, path, human_ppi_f, gmt_path):
    pre_df = pre_df[pre_df['NOM p-val'] < 0.05].reset_index(drop=True)
    cell_geneset_df = pd.DataFrame(columns=['Genes', 'Cluster', 'Cell_Type'])

    for index, row in pre_df.iterrows():
        genes = celltp_clu_gene[row['cell type']][row['Term']]
        if len(genes) > 20:
            avg_clu = count_commu(genes, human_ppi_f)  # Pass human_ppi_f here
            if avg_clu > 0.3:
                cell_geneset_df.loc[index] = [genes, row['Term'], row['cell type']]

    for index, row in cell_geneset_df.iterrows():
        genelist = row['Genes']
        enr = gseapy.enrichr(gene_list=genelist, gene_sets=gmt_path, organism='Human', outdir=None, cutoff=1)
        enr.results.Term = enr.results.Term.apply(lambda x: x[5:].replace('_', ' '))
        export_path = f'{path}/{row["Cell_Type"]}_{row["Cluster"]}_GO_2023.csv'
        enr.results.to_csv(export_path, index=False)

    return cell_geneset_df

# PPI Density Calculation
def count_commu(protein_set, human_ppi_f):
    dataGO = human_ppi_f[(human_ppi_f['pro1_gene'].isin(protein_set)) & (human_ppi_f['pro2_gene'].isin(protein_set))]
    allnode = list(set(dataGO['pro1_gene'].values) | set(dataGO['pro2_gene'].values))
    alledges = [(dataGO.loc[i, 'pro1_gene'], dataGO.loc[i, 'pro2_gene']) for i in dataGO.index]
    
    G = nx.Graph()
    G.add_nodes_from(allnode)
    G.add_edges_from(alledges)
    
    dele_node = [i for i in allnode if G.degree(i) == 1 and i not in protein_set]
    for exc in dele_node:
        G.remove_node(exc)
        
    try:
        av_clu = nx.average_clustering(G)
    except:
        av_clu = -1
        
    return av_clu

def main(uni_gene_path, human_ppi_f_path,  gmt_path):
    # Load data and gene orders
    uni_gene, human_ppi_f, gene_uni_dict = load_data(uni_gene_path, human_ppi_f_path)
    celltp_clu_uni, celltp_clu_gene = load_gene_orders('scPhaSeMod', gene_uni_dict)
    
    # Run GSEA analysis
    pre_df = run_gsea_analysis(celltp_clu_gene, gene_uni_dict, uni_gene, gmt_path)
    
    # Filter and save results
    cell_geneset_df = filter_and_save_results(pre_df, celltp_clu_gene, 'scPhaSeMod', human_ppi_f, gmt_path)

    return pre_df, cell_geneset_df