

#' Soft Clustering for Gene Expression Data
#'
#' This function performs soft clustering on gene expression data using the Mfuzz package.
#'
#' @param scRNA 
#' @param celltype 
#' @param timepoints 
#' @export
calculate_mean <- function(scRNA, celltype, timepoints) {
    library(Seurat)
    library(Matrix)
    library(stringr)
    library(Mfuzz)
    library(dplyr)
    library(reticulate)
    # Set the folder path
    folder_path <- "scPhaSeMod"

    # Check if the folder exists
    if (!dir.exists(folder_path)) {
        # If it doesn't exist, create the folder
        dir.create(folder_path)
        cat("Folder created:", folder_path, "\n")
    } else {
        cat("Folder already exists:", folder_path, "\n")
    }

    types <- names(table(scRNA[[celltype]]))
    for (type in types) {
        temp_scRNA <- scRNA[, which(x = FetchData(object = scRNA, vars = celltype) ==
            type)]
        target_df <- temp_scRNA@assays$RNA@scale.data
        scale_data <- as.data.frame(t(target_df))
        scale_data$stage <- temp_scRNA[[timepoints]]

        rm_index <- length(colnames(scale_data))
        length = length(names(table(scale_data$stage)))
        data_frame_list <- vector("list", length = length)
        for (i in 1:length) {
            key <- names(table(scale_data$stage))[i]
            sep_data <- scale_data[scale_data$stage == key, ][, -rm_index]
            delete_index = length(colnames(sep_data))
            sep_data_1 <- as.data.frame(t(sep_data))
            sep_data_1 <- as.data.frame(lapply(sep_data_1, as.numeric))
            rownames(sep_data_1) <- colnames(sep_data)
            rownames(sep_data_1) <- colnames(sep_data)
            data_frame_list[[i]] = apply(sep_data_1, 1, mean)
        }
        combine_data <- do.call(cbind, data_frame_list)
        colnames(combine_data) <- names(table(scale_data$stage))
        rownames(combine_data) <- rownames(target_df)
        write.csv(combine_data, paste0("scPhaSeMod/timepoint_mean_data_", type, ".csv"), row.names = TRUE)
    }

}   


#' Soft Clustering for Gene Expression Data
#'
#' This function performs soft clustering on gene expression data using the Mfuzz package.
#'
#' @param celltype The type of cells to analyze.
#' @param cluster_num The number of clusters.
#' @param showDF Logical, whether to show data frame. Default is FALSE
#' @param save Logical, whether to save the plot. Default is FALSE.
#' @param showPic Logical, whether to show the picture. Default is TRUE.
#' @return A list containing clustering results.
#' @export
mfuzz_analysis <- function(scRNA, celltype, cluster_num, showDF = FALSE, save = FALSE, showPic = TRUE) {
    mean_raw <- read.csv(paste0("scPhaSeMod/timepoint_mean_data_", celltype, ".csv"), row.names = 1, check.names = FALSE)
    vars <- VariableFeatures(scRNA) %>% as.vector()
    mean_expr <- mean_raw[vars, ][order(vars), ]

    if (showDF) {
        mean_expr %>% head(., 3) %>% print()
        dim(mean_expr) %>% print()
    }

    mfuzz_ <- as.matrix(mean_expr)
    mfuzz_class <- new('ExpressionSet', exprs = mfuzz_)

    mfuzz_class <- filter.NA(mfuzz_class, thres = 0.25)
    mfuzz_class <- fill.NA(mfuzz_class, mode = 'knn')
    mfuzz_class <- filter.std(mfuzz_class, min.std = 0)
    mfuzz_class <- standardise(mfuzz_class)

    set.seed(321)
    mest <- mestimate(mfuzz_class)
    mfuzz_cluster <- mfuzz(mfuzz_class, c = cluster_num, m = mest)

    if (showPic) {
        mfuzz.plot2(mfuzz_class, cl = mfuzz_cluster, x11 = FALSE, mfrow = c(4, 2), time.labels = colnames(mfuzz_),
                    cex.axis = 2, cex.lab = 2, cex.main = 2, centre = TRUE, centre.lwd = 5,
                    centre.col = '#b56a6f')
    }

    if (save) {
        pdf(paste0("scPhaSeMod/", celltype, "_cl", cluster_num, ".pdf"), width = 20, height = 30)
        mfuzz.plot2(mfuzz_class, cl = mfuzz_cluster, x11 = FALSE, mfrow = c(4, 2), time.labels = colnames(mfuzz_),
                    cex.axis = 2, cex.lab = 2, cex.main = 2, centre = TRUE, centre.lwd = 5,
                    centre.col = '#b56a6f')
        dev.off()
    }
    return(list(mfuzz_ = mfuzz_, mfuzz_cluster = mfuzz_cluster, mfuzz_class = mfuzz_class))
}

#' Gene Order Analysis Based on Clustering Results
#'
#' This function analyzes gene order based on clustering results.
#'
#' @param mfuzz_result A list returned from mfuzz_analysis.
#' @param celltype The type of cells to analyze.
#' @param pearson.prop The probability for pearson correlation.
#' @param showDF Logical, whether to show data frame. Default is FALSE
#' @param save Logical, whether to save the result. Default is FALSE.
#' @return A data frame with gene order analysis results.
#' @export
mfuzz_geneOrder <- function(mfuzz_result, celltype, pearson.prop, showDF = FALSE, save = TRUE) {
     mfuzz_ <- mfuzz_result[[1]]
    mfuzz_cluster <- mfuzz_result[[2]]
    mfuzz_class <- mfuzz_result[[3]]
    
    mfuzz_cluster_results <- as.data.frame(mfuzz_cluster$cluster)
    colnames(mfuzz_cluster_results) <- c("mfuzz_cluster")

    mfuzz_center_score <- mfuzz_cluster$membership %>% as.data.frame()
    colnames(mfuzz_center_score) <- paste("cluster_",(colnames(mfuzz_center_score) %>% as.vector()))
    mfuzz_center_score$cluster <- mfuzz_cluster_results$mfuzz_cluster %>% as.vector()
    if(showDF){
        print("mfuzz_center_score:")
        head(mfuzz_center_score,3) %>% print()}

    cluster <- mfuzz_cluster$cluster
    cluster <- cbind(mfuzz_[names(cluster), ], cluster)
    cluster <- as.data.frame(cluster)
    if(showDF){
        print("cluster:")
        head(cluster,3) %>% print()}

    standard_expr <- mfuzz_class@assayData$exprs %>% as.data.frame()
    standard_expr["cluster"] <- cluster$cluster %>% as.vector()
    if(showDF){
        print("standard_expr:")
        head(standard_expr,3) %>% print()}
    centers_ <- mfuzz_cluster$centers %>% as.data.frame()
    cluster_num <- length(colnames(mfuzz_center_score)) - 1
    if(showDF){
        print("centers:")
        centers_ %>% print()}

    vector_list <- vector("list", length = dim(centers_)[1])
    vector_list_cluster <- vector("list", length = dim(centers_)[1])
    for (i in 1:length(vector_list)) {
        Centers1 <- centers_[rownames(centers_) == i, ]
        t(as.matrix(Centers1)) %>% as.data.frame() -> vector_list[[i]]

        Centers2 <- standard_expr[standard_expr$cluster ==i, -dim(standard_expr)[2] ]
        Centers2 <- as.matrix(Centers2) %>% t() %>% as.data.frame() -> vector_list_cluster[[i]]
    }

    final_result <- data.frame()
    for (x in 1:length(vector_list)) {
        result <- c()
        for (i in 1:length(colnames(vector_list_cluster[[x]]))){
            result <- c(result, cor(vector_list_cluster[[x]][, i], vector_list[[x]][,1],
                            method = "pearson") %>% round(., 2))
            # pearson correlation as a score for centers
        }
        df_pearson <- data.frame(pearson = result,
                                 gene = colnames(vector_list_cluster[[x]]),
                                 cluster = rep(x,length(result)))
        df_pearson <- df_pearson[order(df_pearson$pearson, decreasing = T),]
        final_result <- rbind(final_result, df_pearson)
    }
    if(showDF){
        print("final_result:")
        head(final_result,3) %>% print()}

    plot(pearson~cluster, data=final_result)
    boxplot(pearson~cluster,data=final_result)

    final_result %>% group_by(cluster) %>%
    slice_max(., order_by = pearson, prop = pearson.prop) %>% as.data.frame() -> tmp
    print("Table of clusters:")
    tmp$cluster %>% table() %>% print()
    plot(pearson~cluster ,data=tmp)
    paste0("Pearson Prop: ",pearson.prop,"The minimal pearson correlation: ",min(tmp$pearson)) %>% print()
    if(save){
        write.csv(final_result,paste0('scPhaSeMod/',celltype,'_GeneOrder_origin.csv'))
    }
    return(final_result)
}